exports.paymentStatus = {
    PAYED: 'PAYED',
    UNPAYED: 'UNPAYED'
} 
