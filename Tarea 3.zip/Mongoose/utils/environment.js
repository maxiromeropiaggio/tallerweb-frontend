exports.environment = {
    db_name: "test",
    db_url: `mongodb://${db_username}:${db_password}@localhost:27017/` + db_name,
    db_username: "maxi",
    db_password: "hola"

}
